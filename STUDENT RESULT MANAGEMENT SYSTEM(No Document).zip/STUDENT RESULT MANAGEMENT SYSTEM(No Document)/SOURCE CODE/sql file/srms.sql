-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2022 at 09:17 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `srms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', 'f925916e2754e5e03f75dd58a5733251', '2022-01-01 10:30:57');

-- --------------------------------------------------------

--
-- Table structure for table `tblclasses`
--

CREATE TABLE `tblclasses` (
  `id` int(11) NOT NULL,
  `ClassName` varchar(80) DEFAULT NULL,
  `ClassNameNumeric` int(4) DEFAULT NULL,
  `Section` varchar(5) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclasses`
--

INSERT INTO `tblclasses` (`id`, `ClassName`, `ClassNameNumeric`, `Section`, `CreationDate`, `UpdationDate`) VALUES
(1, 'Class Tenth', 10, 'A', '2022-04-09 06:47:20', NULL),
(2, 'Class Twelfth', 12, 'A', '2022-04-09 06:48:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblnotice`
--

CREATE TABLE `tblnotice` (
  `id` int(11) NOT NULL,
  `noticeTitle` varchar(255) DEFAULT NULL,
  `noticeDetails` mediumtext DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblnotice`
--

INSERT INTO `tblnotice` (`id`, `noticeTitle`, `noticeDetails`, `postingDate`) VALUES
(1, 'Notice regarding result Delearation', 'Dear students it is to inform that your final exam have finished. The results of your final exam will be declared soon…  Note : 1st, 2nd, 3rd rank holders will be awarded a trophy in the morning assembly.', '2022-01-01 14:34:58'),
(2, 'Test Notice', 'This is for testing purposes only.  ', '2022-01-01 14:48:32'),
(3, 'Exam Results', 'Half-Yearly Exam 10th Results are published. Students can check on the portal using their valid Roll ID.', '2022-04-09 07:05:59');

-- --------------------------------------------------------

--
-- Table structure for table `tblresult`
--

CREATE TABLE `tblresult` (
  `id` int(11) NOT NULL,
  `StudentId` int(11) DEFAULT NULL,
  `ClassId` int(11) DEFAULT NULL,
  `SubjectId` int(11) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblresult`
--

INSERT INTO `tblresult` (`id`, `StudentId`, `ClassId`, `SubjectId`, `marks`, `PostingDate`, `UpdationDate`) VALUES
(1, 1, 1, 2, 100, '2022-04-09 07:03:21', NULL),
(2, 1, 1, 3, 99, '2022-04-09 07:03:21', NULL),
(3, 1, 1, 4, 98, '2022-04-09 07:03:21', NULL),
(4, 1, 1, 5, 97, '2022-04-09 07:03:21', NULL),
(5, 1, 1, 1, 89, '2022-04-09 07:03:21', NULL),
(6, 2, 1, 2, 87, '2022-04-09 07:03:36', NULL),
(7, 2, 1, 3, 88, '2022-04-09 07:03:36', NULL),
(8, 2, 1, 4, 89, '2022-04-09 07:03:36', NULL),
(9, 2, 1, 5, 67, '2022-04-09 07:03:36', NULL),
(10, 2, 1, 1, 100, '2022-04-09 07:03:36', NULL),
(11, 3, 1, 2, 100, '2022-04-09 07:03:49', NULL),
(12, 3, 1, 3, 87, '2022-04-09 07:03:49', NULL),
(13, 3, 1, 4, 56, '2022-04-09 07:03:49', NULL),
(14, 3, 1, 5, 99, '2022-04-09 07:03:49', NULL),
(15, 3, 1, 1, 89, '2022-04-09 07:03:49', NULL),
(16, 4, 1, 2, 100, '2022-04-09 07:04:01', NULL),
(17, 4, 1, 3, 78, '2022-04-09 07:04:01', NULL),
(18, 4, 1, 4, 99, '2022-04-09 07:04:01', NULL),
(19, 4, 1, 5, 98, '2022-04-09 07:04:01', NULL),
(20, 4, 1, 1, 77, '2022-04-09 07:04:01', NULL),
(21, 5, 1, 2, 98, '2022-04-09 07:04:39', NULL),
(22, 5, 1, 3, 98, '2022-04-09 07:04:39', NULL),
(23, 5, 1, 4, 96, '2022-04-09 07:04:39', NULL),
(24, 5, 1, 5, 93, '2022-04-09 07:04:39', NULL),
(25, 5, 1, 1, 95, '2022-04-09 07:04:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `StudentId` int(11) NOT NULL,
  `StudentName` varchar(100) DEFAULT NULL,
  `RollId` varchar(100) DEFAULT NULL,
  `StudentEmail` varchar(100) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `DOB` varchar(100) DEFAULT NULL,
  `ClassId` int(11) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL,
  `Status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`StudentId`, `StudentName`, `RollId`, `StudentEmail`, `Gender`, `DOB`, `ClassId`, `RegDate`, `UpdationDate`, `Status`) VALUES
(1, 'Anu', '101', 'anu101@gmail.com', 'Female', '2007-01-01', 1, '2022-04-09 06:54:47', NULL, 1),
(2, 'Bala', '102', 'bala102@gmail.com', 'Male', '2007-01-02', 1, '2022-04-09 06:55:18', NULL, 1),
(3, 'Charika', '103', 'charika103@gmail.com', 'Female', '2007-01-03', 1, '2022-04-09 06:56:04', NULL, 1),
(4, 'Dinesh', '104', 'dinesh104@gmail.com', 'Male', '2015-01-04', 1, '2022-04-09 06:56:57', NULL, 1),
(5, 'Elakiya', '105', 'elakiya105@gmail.com', 'Female', '2007-01-05', 1, '2022-04-09 06:57:23', NULL, 1),
(6, 'Abhiney', '121', 'abhiney121@gmail.com', 'Male', '2005-02-01', 2, '2022-04-09 06:58:27', NULL, 1),
(7, 'Bhuna', '122', 'bhuna122@gmail.com', 'Female', '2005-02-02', 2, '2022-04-09 06:59:28', NULL, 1),
(8, 'Chandru', '123', 'chandru123@gmail.com', 'Male', '2005-02-03', 2, '2022-04-09 07:00:39', NULL, 1),
(9, 'Diana', '124', 'diana104@gmail.com', 'Female', '2005-02-04', 2, '2022-04-09 07:01:26', NULL, 1),
(10, 'Elango', '125', 'elango125@gmail.com', 'Male', '2005-02-05', 2, '2022-04-09 07:02:13', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblsubjectcombination`
--

CREATE TABLE `tblsubjectcombination` (
  `id` int(11) NOT NULL,
  `ClassId` int(11) DEFAULT NULL,
  `SubjectId` int(11) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `Updationdate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsubjectcombination`
--

INSERT INTO `tblsubjectcombination` (`id`, `ClassId`, `SubjectId`, `status`, `CreationDate`, `Updationdate`) VALUES
(1, 1, 1, 1, '2022-04-09 06:49:28', NULL),
(2, 1, 2, 1, '2022-04-09 06:49:32', NULL),
(3, 1, 3, 1, '2022-04-09 06:49:35', NULL),
(4, 1, 4, 1, '2022-04-09 06:49:39', NULL),
(5, 1, 5, 1, '2022-04-09 06:49:45', NULL),
(6, 2, 1, 1, '2022-04-09 06:49:49', NULL),
(7, 2, 2, 1, '2022-04-09 06:49:52', NULL),
(8, 2, 3, 1, '2022-04-09 06:49:58', NULL),
(9, 2, 6, 1, '2022-04-09 06:50:02', NULL),
(10, 2, 7, 1, '2022-04-09 06:50:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblsubjects`
--

CREATE TABLE `tblsubjects` (
  `id` int(11) NOT NULL,
  `SubjectName` varchar(100) NOT NULL,
  `SubjectCode` varchar(100) DEFAULT NULL,
  `Creationdate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsubjects`
--

INSERT INTO `tblsubjects` (`id`, `SubjectName`, `SubjectCode`, `Creationdate`, `UpdationDate`) VALUES
(1, 'Tamil', '01', '2022-04-09 06:48:35', NULL),
(2, 'English', '02', '2022-04-09 06:48:38', NULL),
(3, 'Maths', '03', '2022-04-09 06:48:43', NULL),
(4, 'Science', '04', '2022-04-09 06:48:48', NULL),
(5, 'Social Studies', '05', '2022-04-09 06:48:52', NULL),
(6, 'Physics', '06', '2022-04-09 06:49:01', NULL),
(7, 'Chemistry', '07', '2022-04-09 06:49:14', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblclasses`
--
ALTER TABLE `tblclasses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblnotice`
--
ALTER TABLE `tblnotice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblresult`
--
ALTER TABLE `tblresult`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`StudentId`);

--
-- Indexes for table `tblsubjectcombination`
--
ALTER TABLE `tblsubjectcombination`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsubjects`
--
ALTER TABLE `tblsubjects`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblclasses`
--
ALTER TABLE `tblclasses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblnotice`
--
ALTER TABLE `tblnotice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblresult`
--
ALTER TABLE `tblresult`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `StudentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblsubjectcombination`
--
ALTER TABLE `tblsubjectcombination`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblsubjects`
--
ALTER TABLE `tblsubjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
